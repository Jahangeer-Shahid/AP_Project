package com.shopapp.ui.const

object Constant {

    const val DEFAULT_PER_PAGE_COUNT = 10
    const val DEFAULT_STRING = ""
}