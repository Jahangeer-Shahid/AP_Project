package com.shopapp.ui.base.ui

interface FragmentVisibilityListener {

    fun changeVisibility(isVisible: Boolean)

}