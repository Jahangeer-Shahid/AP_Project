package com.shopapp.ui.const


enum class PaymentType {
    WEB_PAYMENT, CARD_PAYMENT, ANDROID_PAYMENT
}