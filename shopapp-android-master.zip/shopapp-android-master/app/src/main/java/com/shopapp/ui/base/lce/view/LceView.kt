package com.shopapp.ui.base.lce.view

interface LceView {

    fun changeState(state: LceLayout.LceState)
}